# 4w4 - Conception d'interface et développement Web
### Auteur : Sara
### Lab4
### Utilisation de l'engin de recherche de WP
###### get_home_url('/')
###### get_search_query()
###### get_search_form()

Site web - wordpress
travail étudiant