<div id="sidebar-footer_ligne_1" class="sidebar">
    <?php dynamic_sidebar( 'footer_ligne_1' ); ?>
</div>