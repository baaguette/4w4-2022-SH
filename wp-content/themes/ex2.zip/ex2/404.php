<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package underscore
 */

get_header(); ?>

<main class="site__main">
<h1>------404------</h1>
	<section class="erreur">
        <h1>La page n'existe pas</h1>
    </section>
		
</main>

<?php get_footer(); ?>