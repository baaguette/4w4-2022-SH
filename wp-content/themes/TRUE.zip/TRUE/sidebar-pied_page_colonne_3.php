<div id="sidebar-primary" class="sidebar">
    <?php dynamic_sidebar( 'pied_page_colonne_3' ); ?>
</div>