<?php get_header(); ?>
<main class="site__main">
<section class="erreur-404">
    <h1>Erreur 404</h1>
    <h2>La page que vous cherchez n'exite pas</h2>
    <p>Essayez plutôt un choix parmi les choix de menu principal</p>
</section>


</main>
<?php get_footer(); ?>