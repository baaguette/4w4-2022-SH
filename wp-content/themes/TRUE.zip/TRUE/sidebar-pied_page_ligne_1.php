<div id="sidebar-primary" class="sidebar">
    <?php dynamic_sidebar( 'pied_page_ligne_1' ); ?>
</div>