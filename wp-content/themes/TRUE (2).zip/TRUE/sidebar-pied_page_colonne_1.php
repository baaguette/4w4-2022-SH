<div id="sidebar-primary" class="sidebar">
    <?php dynamic_sidebar( 'pied_page_colonne_1' ); ?>
</div>